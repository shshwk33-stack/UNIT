"""Build a main six-slide presentation and extract four content pages."""
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

OUT = Path(__file__).parent
prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
FONT = 'Noto Sans CJK KR'
INK = '173C34'
GREEN = '087C68'
PALE = 'E6F1E9'
PAPER = 'F7F7EF'
GRAY = '5A6D64'
ORANGE = 'A7481F'
WARM = 'FFF0DC'
WHITE = 'FFFFFF'


def rect(s, x, y, w, h, fill, line=None, radius=False):
    shape = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,
                               Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid(); shape.fill.fore_color.rgb = RGBColor.from_string(fill)
    if line:
        shape.line.color.rgb = RGBColor.from_string(line)
    else:
        shape.line.fill.background()
    if radius:
        shape.adjustments[0] = 0.08
    return shape


def text(s, x, y, w, h, content, size=20, color=INK, bold=False, align=None):
    box = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame; tf.clear(); tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(0.02)
    tf.margin_top = tf.margin_bottom = Inches(0.01)
    for i, line in enumerate(content.split('\n')):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line; p.font.name = FONT; p.font.size = Pt(size)
        p.font.bold = bold; p.font.color.rgb = RGBColor.from_string(color)
        p.space_before = Pt(0); p.space_after = Pt(3)
        if align is not None: p.alignment = align
    return box


def arrow(s, x, y, w, color=GREEN):
    shape = s.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(x), Inches(y), Inches(w), Inches(.22))
    shape.fill.solid(); shape.fill.fore_color.rgb = RGBColor.from_string(color)
    shape.line.fill.background()


def page(n, topic, title, subtitle=None):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    s.background.fill.solid(); s.background.fill.fore_color.rgb = RGBColor.from_string(PAPER)
    rect(s, 0, 0, .13, 7.5, GREEN)
    text(s, .55, .27, 10.8, .28, 'CBP · 탄소예산 기반 빈 파렛트 회수예약   /   두런두런', 12, GREEN, True)
    text(s, 11.4, .27, 1.32, .28, f'IDEA {n:02}', 12, GRAY, True, PP_ALIGN.RIGHT)
    text(s, .55, .81, 12.2, 1.18, title, 31, INK, True)
    if subtitle: text(s, .58, 2.01, 12.1, .5, subtitle, 16, GRAY)
    rect(s, .55, 7.04, 12.2, .012, 'CFDAD0')
    text(s, .56, 7.13, 11.8, .22, '제13회 유닛로드시스템(ULS) 창의성 공모전  |  아이디어 검토안 · 현장 실증 전', 10, GRAY)
    return s


def pallet(s, x, y, count=3, scale=1):
    for i in range(count):
        yy = y - i * .15 * scale
        rect(s, x, yy, 1.12 * scale, .09 * scale, 'BD8A51')
        for xx in [x+.08*scale, x+.51*scale, x+.94*scale]:
            rect(s, xx, yy+.085*scale, .10*scale, .07*scale, '8F643A')


def truck(s, x, y):
    rect(s, x, y, 1.08, .48, PALE, GREEN)
    rect(s, x+1.08, y+.16, .35, .32, GREEN)
    for dx in [.25, 1.10]:
        c=s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x+dx), Inches(y+.43), Inches(.20), Inches(.20))
        c.fill.solid(); c.fill.fore_color.rgb=RGBColor.from_string(INK); c.line.fill.background()


s = page(1, '문제와 제안', '빈 파렛트가 급해지기 전에,\n돌아오는 차의 빈칸부터 예약.',
         '파렛트가 필요한 시점과 배송차가 돌아오는 시점을 연결합니다.')
rect(s,.58,2.78,3.18,2.40,WHITE,radius=True)
text(s,.83,2.98,2.7,.35,'회수할 파렛트가 있는 거점',18,INK,True)
pallet(s,1.55,4.42,4)
text(s,.85,4.77,2.65,.28,'같은 풀링사 · 호환 규격',13,GRAY)
rect(s,9.55,2.78,3.18,2.40,WHITE,radius=True)
text(s,9.82,2.98,2.68,.35,'다음 출고를 앞둔 거점',18,INK,True)
text(s,9.83,3.57,2.54,.56,'16시까지',28,GREEN,True)
text(s,9.83,4.16,2.54,.47,'빈 파렛트 160매 필요',17,INK,True)
arrow(s,3.95,3.83,1.05);arrow(s,8.25,3.83,1.05)
truck(s,5.75,3.16)
text(s,4.70,4.02,3.85,.34,'이미 예정된 복귀편에',20,GREEN,True,PP_ALIGN.CENTER)
text(s,4.70,4.42,3.85,.34,'실을 수 있는 공간이 있다면?',17,INK,False,PP_ALIGN.CENTER)
rect(s,.58,5.62,12.15,.99,PALE,radius=True)
text(s,.84,5.83,11.55,.62,'부족해진 뒤 긴급 배차  →  필요 시점 확인 · 복귀편 사전 예약',22,GREEN,True)
text(s,.62,6.71,12.1,.21,'장면은 검증할 현장 가설입니다. 가용 공간·회수 수요가 맞는 경우에 적용합니다.',11,GRAY)
s.notes_slide.notes_text_frame.text = '메인 2장, 0:10~0:45. 화면의 수량과 시각은 가상 예시. 급해지기 전에 회수 대안을 확보한다는 장면으로 시작한다. 실제 현장의 긴급 회수 빈도는 조사 전이므로 통계를 주장하지 않는다.'

s = page(2, '작동 원리', '필요 시점부터 거꾸로,\n회수 방법을 결정합니다.',
         '핵심은 재고에 맞춘 기한, 운반 가능한 빈칸, 그리고 예약까지 반영한 탄소예산입니다.')
for x, num, heading, body in [
    (.58,'01','언제까지 필요한가','예정 출고 · 재고 · 안전재고\n→ 필요 수량과 도착 마감 확인'),
    (4.72,'02','어느 차에 실을 수 있나','동일 풀링사 · 적재 안전 · 도착 시각\n→ 실제 운반 가능한 복귀편만 선택'),
    (8.86,'03','어떤 조합을 예약할까','기한·수량 충족 + 탄소예산 준수\n→ 그중 추가 회수비가 낮은 조합')]:
    rect(s,x,2.83,3.86,1.84,WHITE,radius=True)
    text(s,x+.20,2.99,.55,.32,num,18,GREEN,True)
    text(s,x+.20,3.43,3.45,.37,heading,20,INK,True)
    text(s,x+.20,3.98,3.45,.56,body,13,GRAY)
rect(s,.58,4.99,12.15,.94,INK,radius=True)
text(s,.84,5.16,11.65,.51,'쓸 수 있는 탄소 = 총예산 − 기배출 − 확정된 향후 운행의 예약분',21,WHITE,True)
text(s,.67,6.13,12.0,.57,'복귀편을 예약해도 끝이 아닙니다.\n대체 회수차를 보낼 수 있는 마감 전에, 지연과 적재 공간을 다시 확인합니다.',17,INK)
s.notes_slide.notes_text_frame.text = '메인 3장, 0:45~1:45. 초기 입력은 담당자가 확인한 필요량과 기한이다. AI 수요예측이나 실시간 TMS 연동을 구현했다고 말하지 않는다. 확정된 향후 운행을 예산에서 예약 차감한다는 점을 설명한다. 지연 시 대체차를 보낼 수 있는 시점 이전에 재판단하는 것은 제안한 운영 규칙이며 현장 검증 전이다.'

s = page(3, '동일 조건 비교', '같은 기한·같은 물량에서,\n탄소예산이 선택을 바꿉니다.')
rect(s,.58,2.13,12.15,.48,WARM,radius=True)
text(s,.78,2.21,11.72,.27,'작동 원리 설명용 가상 예시  |  실제 운임·배출계수 또는 실증 결과가 아닙니다.',14,ORANGE,True)
text(s,.62,2.84,11.95,.45,'공통 조건: 160매 · 16시까지 도착 · 이번 회수 탄소예산 70kgCO₂e',20,INK,True)
for x, label, title, cost, co2, time, fill, accent in [
    (.58,'동일 정보 · 비용 최소안','전용 회수차','120,000원','90kgCO₂e','13시 도착',WHITE,ORANGE),
    (6.80,'CBP · 탄소예산 준수안','복귀편 A 100매 + B 60매','135,000원','65kgCO₂e','14시·15시 도착',PALE,GREEN)]:
    rect(s,x,3.50,5.93,2.22,fill,radius=True)
    text(s,x+.22,3.66,5.42,.27,label,13,accent,True)
    text(s,x+.22,4.03,5.42,.41,title,21,INK,True)
    text(s,x+.22,4.63,2.64,.49,cost,26,INK,True)
    text(s,x+2.92,4.63,2.83,.49,co2,25,accent,True)
    text(s,x+.22,5.25,5.42,.24,time,13,GRAY)
text(s,.69,6.00,11.95,.44,'이 가상 입력에서는  +15,000원으로 25kgCO₂e를 줄이는 선택',22,GREEN,True)
text(s,.67,6.58,12.01,.32,'공통 배송 본선은 동일 운행으로 가정. 회수로 달라지는 비용·배출만 비교하며, 복귀편 추가 배출도 0이 아닙니다.',11,GRAY)
s.notes_slide.notes_text_frame.text = '메인 4장, 1:45~2:40. 가상 예시임을 말로도 밝힌다. 두 안에 같은 정보와 기한을 제공한다. 비용과 탄소의 상충을 인정한다. 예산을 100kg으로 완화하면 두 정책 모두 전용차를 고르므로 별도 감축 효과는 없다. 수치는 현장 입력으로 교체해야 한다.'

s = page(4, '예외 처리와 검증', '예약이 어긋나도,\n다음 출고를 지키는 회수.',
         '복귀편 활용만으로 끝내지 않고, 실패했을 때의 운영 규칙까지 설계합니다.')
rows=[('차량이 늦거나 공간이 사라지면','대체차 출발 마감 전에 재확인하고 다른 회수안 제시'),
      ('기한과 탄소예산을 함께 못 지키면','회수를 자동 중단하지 않고, 초과량을 보여줘 담당자 승인'),
      ('실제 효과는 어떻게 확인하나','같은 수요·정보·기한에서 비용 최소안과 공정하게 비교')]
for i,(a,b) in enumerate(rows):
    y=2.79+i*.77
    rect(s,.58,y,12.15,.63,WHITE,radius=True)
    text(s,.78,y+.12,4.04,.34,a,17,GREEN,True)
    text(s,4.93,y+.12,7.49,.34,b,16,INK)
rect(s,.58,5.37,12.15,1.20,PALE,radius=True)
text(s,.83,5.54,11.55,.33,'첫 적용: 동일 풀링사 2~3개 거점에서 예약 추천부터',20,GREEN,True)
text(s,.83,6.03,11.55,.30,'검증할 지표  |  납기·수량 준수 / 총 회수비 / 추가 배출 / 긴급 전용차 투입 횟수',15,INK)
text(s,.66,6.74,12.0,.20,'계산 데모는 합성 입력으로 확인했습니다. 현장 실증·독창성 검토는 추가 과제입니다.',11,GRAY)
s.notes_slide.notes_text_frame.text = '메인 5장, 2:40~3:35. 복귀차 지연, 적재 실패, 예산 불가능을 구분한다. 자동으로 납기를 희생하지 않는다. 백홀 자체가 신규라는 주장을 하지 않고 재고·기한·탄소 예약과 대체 회수 마감의 결합을 차별성 후보로 설명한다. 소규모 현장 검증 계획을 설명한다.'

prs.core_properties.title = 'CBP 탄소예산 기반 빈 파렛트 회수예약 — 메인 발표에서 발췌한 배너용 4쪽 검토안'
prs.core_properties.subject = '제13회 ULS 창의성 공모전 본선 아이디어 검토안'
prs.core_properties.author = '두런두런'
prs.core_properties.comments = '합성 수치 사용. 현장 실증 및 선행기술 확인 전. 공식 제출은 사용자가 검토 후 진행.'
path = OUT / 'CBP_본선_배너4쪽_검토안.pptx'
prs.save(path)
print(path)

# The main presentation is the parent deliverable. Its content slides 2--5
# are exactly the same four pages saved above; no independently made banner.
cover=prs.slides.add_slide(prs.slide_layouts[6])
cover.background.fill.solid(); cover.background.fill.fore_color.rgb=RGBColor.from_string(INK)
text(cover,.70,.52,12,.35,'제13회 유닛로드시스템(ULS) 창의성 공모전  /  두런두런',15,'B5D7C8',True)
text(cover,.70,1.55,11.9,.55,'CBP  ·  Carbon Budget Pooling',24,'B5D7C8',True)
text(cover,.70,2.45,11.9,1.95,'빈 파렛트\n회수예약',51,WHITE,True)
rect(cover,.73,5.08,1.0,.055,'9DCDB7')
text(cover,.70,5.47,11.8,.80,'필요한 시점에 맞춰, 돌아오는 차의 빈칸부터.',25,WHITE)
text(cover,.73,6.75,11.7,.30,'탄소예산 기반 유닛로드시스템 운영 최적화  |  본선 발표 검토안',13,'B5D7C8')
cover.notes_slide.notes_text_frame.text='0:00~0:10. 안녕하세요, 두런두런입니다. 저희는 빈 파렛트가 급해지기 전에 회수 방법을 예약하는 CBP를 제안합니다.'
order=prs.slides._sldIdLst
entry=order[-1];order.remove(entry);order.insert(0,entry)

last=prs.slides.add_slide(prs.slide_layouts[6])
last.background.fill.solid();last.background.fill.fore_color.rgb=RGBColor.from_string(INK)
text(last,.73,.54,11.9,.33,'CBP · 빈 파렛트 회수예약',15,'B5D7C8',True)
text(last,.73,1.73,11.85,1.82,'급해진 뒤의 배차를,\n필요 시점에 맞춘 예약으로.',37,WHITE,True)
text(last,.76,4.10,11.75,.75,'재고와 기한을 먼저 확인하고\n비용과 탄소를 함께 판단합니다.',24,'B5D7C8')
rect(last,.76,5.54,11.78,.81,'285347',radius=True)
text(last,1.00,5.75,11.3,.32,'첫 적용  |  동일 풀링사 2~3개 거점 · 담당자 승인 · 동일 조건 비교',18,WHITE,True)
text(last,.76,6.85,11.70,.25,'두런두런  /  제13회 유닛로드시스템(ULS) 창의성 공모전',12,'B5D7C8')
last.notes_slide.notes_text_frame.text='3:35~4:00. 저희는 파렛트가 급해진 뒤 차를 부르는 대신, 필요한 시점에 맞춰 회수 방법을 미리 예약하자고 제안합니다. 같은 정보를 받은 비용 중심 배차와 납기, 회수비, 배출을 비교하겠습니다. 두런두런의 CBP입니다. 감사합니다.'
prs.core_properties.title='CBP 탄소예산 기반 빈 파렛트 회수예약 — 본선 메인 발표 검토안'
main_path=OUT/'CBP_본선_메인발표_검토안.pptx'
prs.save(main_path)
print(main_path)
