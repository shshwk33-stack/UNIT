"""Illustrative CBP selector; synthetic data, not field validation.

Run: python model.py
All jobs are indivisible, pre-checked capacity blocks on one origin/destination.
No external dependencies. Production scheduling needs additional constraints.
"""
from dataclasses import asdict, dataclass, replace
from itertools import combinations
import json


@dataclass(frozen=True)
class Job:
    key: str
    name: str
    pallets: int
    arrival: float
    cost: int
    emissions: float
    compatible: bool = True


JOBS = (
    Job("direct", "전용 회수차", 160, 13, 120000, 90),
    Job("return_a", "복귀편 A", 100, 14, 55000, 35),
    Job("return_b", "복귀편 B", 60, 15, 80000, 30),
    Job("late", "늦은 복귀편", 160, 18, 80000, 45),
    Job("other", "호환 조건 미충족", 160, 14, 70000, 20, False),
)


def select(jobs=JOBS, demand=160, deadline=16, budget=300, used=150, committed=80):
    """Exact enumeration of a tiny finite menu; no partial loading allowed.

    This one-request snapshot assumes stock and vehicle capacity are already
    reserved and no jobs conflict. It does not implement an event ledger,
    demand forecasting, actual emission estimation or unattended dispatch.
    A fallback is only a proposed service-preserving plan requiring approval.
    """
    if demand <= 0 or not 0 <= deadline <= 24:
        raise ValueError("positive demand and deadline in [0,24] required")
    if min(budget, used, committed) < 0:
        raise ValueError("budget ledger values must be nonnegative")
    if len({j.key for j in jobs}) != len(jobs):
        raise ValueError("duplicate job key")
    if any(j.pallets <= 0 or j.cost < 0 or j.emissions < 0 or not 0 <= j.arrival <= 24 for j in jobs):
        raise ValueError("invalid job")
    eligible = [j for j in jobs if j.compatible and j.arrival <= deadline]
    plans = []
    for size in range(1, len(eligible) + 1):
        for batch in combinations(eligible, size):
            if sum(j.pallets for j in batch) == demand:
                plans.append({
                    "jobs": [j.key for j in batch],
                    "names": [j.name for j in batch],
                    "pallets": demand,
                    "arrival": max(j.arrival for j in batch),
                    "cost": sum(j.cost for j in batch),
                    "emissions": sum(j.emissions for j in batch),
                })
    order = lambda p: (p["cost"], p["emissions"], p["jobs"])
    plans.sort(key=order)
    available = budget - used - committed
    compliant = [p for p in plans if p["emissions"] <= available + 1e-9]
    baseline = plans[0] if plans else None
    proposed = compliant[0] if compliant else None
    return {
        "synthetic": True,
        "available": available,
        "eligible": [j.key for j in eligible],
        "plans": plans,
        "baseline": baseline,
        "proposed": proposed,
        "approval_required": bool(baseline and not proposed),
        "fallback_proposal": baseline if not proposed else None,
        "service_infeasible": not plans,
    }


def validate():
    basic = select()
    assert basic["baseline"]["jobs"] == ["direct"]
    assert basic["baseline"]["cost"] == 120000
    assert basic["proposed"]["jobs"] == ["return_a", "return_b"]
    assert (basic["proposed"]["cost"], basic["proposed"]["emissions"]) == (135000, 65)
    assert {tuple(p["jobs"]) for p in basic["plans"]} == {("direct",), ("return_a", "return_b")}
    loose = select(budget=330)
    assert loose["proposed"] == loose["baseline"]
    tight = select(budget=290)
    assert tight["proposed"] is None and tight["approval_required"]
    delayed = select(jobs=tuple(replace(j, arrival=17) if j.key == "return_b" else j for j in JOBS))
    assert delayed["proposed"] is None and delayed["fallback_proposal"]["jobs"] == ["direct"]
    no_service = select(deadline=12)
    assert no_service["service_infeasible"] and no_service["fallback_proposal"] is None
    negative_remaining = select(budget=100)
    assert negative_remaining["available"] == -130 and negative_remaining["approval_required"]
    # More permissive emission budgets cannot make the minimum cost higher.
    prior = None
    for cap in range(0, 121):
        result = select(budget=230 + cap)
        if result["proposed"]:
            assert result["proposed"]["cost"] >= result["baseline"]["cost"]
            assert result["proposed"]["emissions"] <= cap + 1e-9
            if prior is not None:
                assert result["proposed"]["cost"] <= prior
            prior = result["proposed"]["cost"]
    print("PASS: normal, loose budget, infeasible budget, delayed return, no service, overcommitted ledger, and 121 budget sensitivity cases")


if __name__ == "__main__":
    validate()
    print(json.dumps(select(), ensure_ascii=False, indent=2))
