// Browser verification of the delivered, offline HTML artifact.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');
(async()=>{
  const html = fs.readFileSync(path.join(__dirname,'demo.html'));
  const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
  try {
  const page=await browser.newPage({viewport:{width:1400,height:1100}});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:'+server.address().port);
  const read=()=>page.evaluate(()=>({baseline:cbpLastResult.baseline&&{cost:cbpLastResult.baseline.cost,emissions:cbpLastResult.baseline.emissions},proposed:cbpLastResult.proposed&&{cost:cbpLastResult.proposed.cost,emissions:cbpLastResult.proposed.emissions}}));
  assert.deepEqual(await read(),{baseline:{cost:120000,emissions:90},proposed:{cost:135000,emissions:65}});
  await page.screenshot({path:path.join(__dirname,'demo-preview.png'),fullPage:true});
  await page.locator('[data-case="loose"]').click();
  assert.deepEqual((await read()).proposed,{cost:120000,emissions:90});
  for(const kind of ['tight','delay']){
    await page.locator(`[data-case="${kind}"]`).click();
    assert.equal((await read()).proposed,null);
    assert.match(await page.locator('#proposed').innerText(),/운영자 승인 필요/);
  }
  await page.locator('[data-case="none"]').click();
  assert.equal((await read()).baseline,null);
  assert.match(await page.locator('#delta').innerText(),/서비스 충족 불가/);
  await page.locator('[data-case="normal"]').click();
  await page.locator('#budget').fill('');
  assert.equal(await page.locator('#remaining').innerText(),'입력 확인');
  await page.locator('[data-case="normal"]').click();
  await page.setViewportSize({width:390,height:844});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true);
  assert.deepEqual(errors,[]);
  console.log('PASS: self-contained page via local HTTP, five scenarios, invalid input, mobile width, zero browser errors');
  } finally {
    await browser.close();
    await new Promise(resolve=>server.close(resolve));
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
